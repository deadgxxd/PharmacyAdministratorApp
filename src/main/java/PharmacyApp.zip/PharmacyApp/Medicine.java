package PharmacyApp;

import java.util.List;

public class Medicine {
	
    private String name;
    private Integer quantity;
    private List<Disease> treats;


    public void SetName(String _name) {

    }

    public String GetName() {
        return name;
    }

    public void SetQuantity(Integer _quantity) {

    }

    public Integer GetQuantity() {
        return quantity;
    }


    public void AddDisease(Disease disease) {

    }

    public void RemoveDisease(Disease disease) {

    }

    public List<Disease> GetTreats() {
        return treats;
    }

    public void RemoveAllDiseases() {

    }
}
